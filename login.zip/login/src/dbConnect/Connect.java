package dbConnect;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connect {
	

	public static Connection con=null;
	public static Connection connectionEst() {
		try {
			if(con==null) {
		Class.forName("com.mysql.jdbc.Driver");
        System.out.println("Driver Loaded..");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/1161096","1161096","9727201414");
        System.out.println("Connection Established..");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}

}
